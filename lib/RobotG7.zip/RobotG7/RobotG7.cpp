#include "RobotG7.h"

#define DEFAULT_TRIG_PIN 4
#define DEFAULT_ECHO_PIN 2

#define LIMIT_GET_OBSTACLE 10 // 10 cm
extern unsigned long previouMillis;

RobotG7::RobotG7(MOTOR *roue1, MOTOR *roue2, int pinCtrlMode)
{
    this->m_gdSound = new GuideSound(DEFAULT_TRIG_PIN, DEFAULT_ECHO_PIN); // (triger, echo)
    this->m_rouesRobots = new MotorControl(roue1, roue2);

    this->cheminAprendre = new CtrlWay(); // Par defaut à la pin 15

    this->systemNav = DEVANT;

    this->m_modeNav = MODE_AUTOMATIQUE;

    // this->m_modeNav = MODE_AUTOMATIQUE;

    // this->ctrlMode = pinCtrlMode;
}

void RobotG7::begin()
{
    // pinMode(this->ctrlMode, INPUT_PULLUP);
    this->m_gdSound->begin();
    this->m_rouesRobots->begin();
    this->cheminAprendre->begin();
}

void RobotG7::deplacementAvant()
{
    digitalWrite(this->m_rouesRobots->getRoue1()->enablePin, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue2()->enablePin, HIGH);

    digitalWrite(this->m_rouesRobots->getRoue1()->cPin1, LOW);
    digitalWrite(this->m_rouesRobots->getRoue1()->cPin2, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue2()->cPin1, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue2()->cPin2, LOW);

    ledcWrite(this->m_rouesRobots->getRoue1()->pwmChannel, 200);
    ledcWrite(this->m_rouesRobots->getRoue2()->pwmChannel, 200);

}
void RobotG7::deplacementArriere()
{
    digitalWrite(this->m_rouesRobots->getRoue1()->enablePin, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue2()->enablePin, HIGH);

    digitalWrite(this->m_rouesRobots->getRoue1()->cPin1, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue1()->cPin2, LOW);
    digitalWrite(this->m_rouesRobots->getRoue2()->cPin1, LOW);
    digitalWrite(this->m_rouesRobots->getRoue2()->cPin2, HIGH);

    ledcWrite(this->m_rouesRobots->getRoue1()->pwmChannel, 190);
    ledcWrite(this->m_rouesRobots->getRoue2()->pwmChannel, 190);

}

void RobotG7::tourner_a_GaucheAvant()
{
    digitalWrite(this->m_rouesRobots->getRoue1()->enablePin, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue2()->enablePin, LOW);

    digitalWrite(this->m_rouesRobots->getRoue1()->cPin1, LOW);
    digitalWrite(this->m_rouesRobots->getRoue1()->cPin2, HIGH);
    // digitalWrite(this->m_rouesRobots->getRoue2()->cPin1, LOW);
    // digitalWrite(this->m_rouesRobots->getRoue2()->cPin1, HIGH);

    ledcWrite(this->m_rouesRobots->getRoue1()->pwmChannel, 190);
    ledcWrite(this->m_rouesRobots->getRoue2()->pwmChannel, 0);
}
void RobotG7::tourner_a_DroiteAvant()
{
    digitalWrite(this->m_rouesRobots->getRoue1()->enablePin, LOW);
    digitalWrite(this->m_rouesRobots->getRoue2()->enablePin, HIGH);

    // digitalWrite(this->m_rouesRobots->getRoue1()->cPin1, LOW);
    // digitalWrite(this->m_rouesRobots->getRoue1()->cPin2, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue2()->cPin1, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue2()->cPin2, LOW);

    ledcWrite(this->m_rouesRobots->getRoue1()->pwmChannel, 0);
    ledcWrite(this->m_rouesRobots->getRoue2()->pwmChannel, 190);
}


void RobotG7::tourner_a_GaucheArriere()
{
    digitalWrite(this->m_rouesRobots->getRoue1()->enablePin, LOW);
    digitalWrite(this->m_rouesRobots->getRoue2()->enablePin, HIGH);

    // digitalWrite(this->m_rouesRobots->getRoue1()->cPin1, LOW);
    // digitalWrite(this->m_rouesRobots->getRoue1()->cPin2, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue2()->cPin1, LOW);
    digitalWrite(this->m_rouesRobots->getRoue2()->cPin2, HIGH);

    ledcWrite(this->m_rouesRobots->getRoue1()->pwmChannel, 190);
    ledcWrite(this->m_rouesRobots->getRoue2()->pwmChannel, 0);
}
void RobotG7::tourner_a_DroiteArriere()
{
    digitalWrite(this->m_rouesRobots->getRoue1()->enablePin, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue2()->enablePin, LOW);

    digitalWrite(this->m_rouesRobots->getRoue1()->cPin1, HIGH);
    digitalWrite(this->m_rouesRobots->getRoue1()->cPin2, LOW);
    // digitalWrite(this->m_rouesRobots->getRoue2()->cPin1, LOW);
    // digitalWrite(this->m_rouesRobots->getRoue2()->cPin1, HIGH);

    ledcWrite(this->m_rouesRobots->getRoue1()->pwmChannel, 0);
    ledcWrite(this->m_rouesRobots->getRoue2()->pwmChannel, 190);
}

void RobotG7::stopRobotG7()
{
    digitalWrite(this->m_rouesRobots->getRoue1()->enablePin, LOW);
    digitalWrite(this->m_rouesRobots->getRoue2()->enablePin, LOW);

    ledcWrite(this->m_rouesRobots->getRoue1()->pwmChannel, 0);
    ledcWrite(this->m_rouesRobots->getRoue2()->pwmChannel, 0);

}

void RobotG7::systemRunningAuto()
{

    switch(this->systemNav)
    {
    case DEVANT :
        Serial.println("On avance !!!");
        if(this->getDistanceObstacle() >= LIMIT_GET_OBSTACLE)
        {
            Serial.println("Permit d'avancer !!!");
            this->deplacementAvant();
        }
        else
        {
            Serial.println("Non Permit d'avancer !!!");
            this->stopRobotG7();
            this->systemNav = this->cheminAprendre->theWayToget(this->m_gdSound);
        }
        break;
    case DERRIERE :
        this->deplacementArriere();
        break;
    case GAUCHE :
        this->tourner_a_GaucheArriere();
        this->systemNav = DEVANT;
        break;
    case DROITE :
        this->tourner_a_DroiteArriere();
        this->systemNav = DEVANT;
        break;
        


    }

}

void RobotG7::systemRunningManual()
{

}

// void RobotG7::runningAutoMode(uint32_t PreviousTime)
// {
   
// }

// void RobotG7::systemRunning()
// {
//     switch (this->m_modeNav)
//     {
//     case MODE_AUTOMATIQUE:
//         /* code */
//         break;
//     case MODE_MANUEL:
//         /* code */
//         break;
    
//     default:
//         break;
//     }
// }

// ++++++++++++++++++++++++ mode de navigation +++++++++++++++++++++++++
void RobotG7::navigation()
{
    switch(this->m_modeNav)
    {
    case MODE_START :
        this->stopRobotG7();
        break;
    case  MODE_AUTOMATIQUE :
        Serial.println("Mode automatique !!!");
        this->systemRunningAuto();
        break;

    case MODE_MANUEL:
        this->systemRunningManual();
        break;

    }
}