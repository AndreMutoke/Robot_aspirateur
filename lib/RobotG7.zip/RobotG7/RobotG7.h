#ifndef ROBOT_GROUPE_7_L4_TLC
#define ROBOT_GROUPE_7_L4_TLC

#include <Arduino.h>

#include "include/GuideSound/GuideSound.h"
#include "include/MotorControl/MotorControl.h"
#include "include/CtrlWay/CtrlWay.h"



enum Navigation
{
    MODE_START,
    MODE_AUTOMATIQUE,
    MODE_MANUEL
};
typedef enum Navigation MODE;

class RobotG7
{
public :
    RobotG7(MOTOR *roue1 = NULL,
            MOTOR *roue2  = NULL, 
            int pinCtlMode = 5
            );
    void begin();
    uint32_t getDistanceObstacle(){return this->m_gdSound->getDistance();}
    int getpwmChannelRoue1(){return this->m_rouesRobots->getRoue1()->pwmChannel;}
    int getpwmChannelRoue2(){return this->m_rouesRobots->getRoue2()->pwmChannel;}

    void deplacementAvant();
    void deplacementArriere();
    void tourner_a_GaucheAvant();
    void tourner_a_DroiteAvant();

    void tourner_a_GaucheArriere();
    void tourner_a_DroiteArriere();

    void stopRobotG7();
    // ++++++++++++++++++ Control Navigation +++++++++++++++++++
    void setNavigation(MODE modeNav){this->m_modeNav = modeNav;}

    // ++++++++++++++++ to control movement ++++++++++++++++++++++++++++
    WAY getSystemNavDirect(){return this->systemNav;}
    void navigation();
    void setSystemNavDirect(WAY direction){ this->systemNav = direction;}
    // ++++++++++++++++++ Control Chemin +++++++++++++++++++++++++++++++

    void systemRunningAuto();
    void systemRunningManual();
private :
    GuideSound *m_gdSound;
    MotorControl *m_rouesRobots;

    CtrlWay *cheminAprendre;

    MODE m_modeNav;

    WAY systemNav;

    // int ctrlMode;

    // void runningAutoMode(uint32_t PreviousTime );

    // MODE m_modeNCaptureObstacleav;
};

#endif // ROBOT_GROUPE_7_L4_TLC