#ifndef GUIDE_SOUND_H
#define GUIDE_SOUND_H

#include <Arduino.h>
#include <Wire.h>

class GuideSound
{
public :
    GuideSound(uint8_t trig = 0, uint8_t echo = 0);
    void begin(); // Initialiser le programme;

    uint32_t getDistance(){ captureDistance_and_Delay(); return this->m_distance;} // Pour nous retourner la distance
    uint32_t getDelayEcho(){ captureDistance_and_Delay(); return this->m_duree;} // POur nous retourner le temps de voyage capturé
private:
    uint8_t m_echo_pin; // Le pin pour recevoir les echos retours
    uint8_t m_trig_pin; // Le pin pour Emettre le son 

    uint32_t m_distance; // Pour calculer et concerver la distance
    uint32_t m_duree; // Pour determiner la duréé du voyage du son émi.
    void captureDistance_and_Delay();

    int pulseEmit();

};

#endif // GUIDE_SOUND_H