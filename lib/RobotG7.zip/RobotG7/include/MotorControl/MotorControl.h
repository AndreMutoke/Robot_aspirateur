#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#include <Arduino.h>


/**
 * PROPRIETIES PWM
*/
#define FREQENCE_CONTROL 30000
#define PWMCHANNEL 0
#define PWMCHANNEL2 1
#define RESOLUTION 8
#define DUTY_CYCLE 170

struct Motor
{
    uint8_t cPin1; // Pin Control 1
    uint8_t cPin2; // Pin Control 2
    uint8_t enablePin; // Pin four enabling

    int pwmChannel; // PWMChannel
};

typedef struct Motor MOTOR;

// void defineMotor(int pin1, int pin2, int enable, int pwmChannel, MOTOR *mot)
// {
//     mot->cPin1 = pin1;
//     mot->cPin2 = pin2;
//     mot->enablePin = enable;

//     mot->pwmChannel = pwmChannel;
// }

class MotorControl
{
public :
    MotorControl(MOTOR *roue1 = NULL,
                 MOTOR *roue2  = NULL                
                 );
    void begin();
    MOTOR *getRoue1(){return this->m_roue1;}
    MOTOR *getRoue2(){return this->m_roue2;}
private:
    MOTOR *m_roue1; // Moteur de la roue 1
    MOTOR *m_roue2; // Moteur de la roue 2

    void configurationMotor();
};

#endif // MOTOR_CONTROL_H