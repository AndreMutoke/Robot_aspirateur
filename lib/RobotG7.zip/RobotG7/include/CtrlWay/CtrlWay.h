#ifndef CTRL_WAY
#define CTRL_WAY

#include <Arduino.h>
#include <ESP32Servo.h>

#include "../GuideSound/GuideSound.h"

enum Way
{
    DEVANT,
    DERRIERE, 
    GAUCHE, 
    DROITE
};
typedef enum Way WAY;

class CtrlWay
{
public : 
    CtrlWay(int pinAttached = 15);
    void begin();

    WAY theWayToget(GuideSound *CaptureObstacle); 



private :
    Servo m_pServo;
    uint8_t m_pin_to_attach;
    int posMotor;

    int seeToLeft(GuideSound *CaptureObstacle);
    int seeToRight(GuideSound *CaptureObstacle);
    int MoyenneDistances(int tab[]);

};

#endif // CTRL_WAY