#ifndef CONTROL_BLE_H
#define CONTROL_BLE_H

#include <Arduino.h>
///Dabble bluetooth////
#define CUSTOM_SETTINGS
#define INCLUDE_GAMEPAD_MODULEpowerChannel
#include <DabbleESP32.h>
///FIN Dabble bluetooth////

class ManualMODE
{
public :
    ManualMODE();
};


#endif // CONTROL_BLE_H